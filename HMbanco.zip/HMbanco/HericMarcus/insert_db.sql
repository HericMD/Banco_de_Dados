
insert into clientes(nome, email, login, senha, endereco_cobranca) values
("Pedro Camargo","pedro.ribeiro@gmail.com","pedro.ribeiro","12@#$0s,k45","Rua dos Empresarios 90823"),
("Julia Ribeiro","julia.ribeiro@gmail.com","julia.ribeiro","12@#$d83j56","Rua dos Bla78364 23"),
("Rose Nascimento","rose@gmail.com","rose.nascimento","12@#$0osl9","Rua dos blablabla 89723"),
("Daniela da Silva","daniela.silva@gmail.com","dani.silva","12@#$9skw4","Rua dos Comerciarios 90");

insert into produtos(qtd_embalagem, preco_embalagem,qtd_estoque,desc_produto,preco_unitario) values 
(1,7580.35,NULL,"Notebook Lenovo",7580.35),
(1,258.25,NULL,"Teclado DELL com fio",258.25),
(1,127.50,NULL,"Mouse DELL com fio",127.50),
(1,1235.48,NULL,"Cadeira Gamer",1235.48),
(1,875.98,NULL,"Monitor DELL FULL HD",875.98),
(1,875.93,NULL,"Mesa escritório 150x85",875.93,
(1,2578.34,NULL,"Projetor SONY 120HZ",2578.34),
(1,120.36,NULL,"AVAST",120.36),
(1,425.38,NULL,"WINDOWS 11",425.38),
(1,1890.35,NULL,"Celular XIAOMI POCO3",1890.35); 


insert into comentario(cod_cliente,cod_produto,texto,titulo)
values  
(5,9,"Otimo muito bom mesmo!","Comentário"),
(6,8,"Pessimo, ruim mesmo!","Comentário"),
(1,6,"Nao gostei","Comentário"),
(6,5,"Funciona muito bem","Comentário"),
(2,6,"Nao funciona mesmo","Comentário"),
(3,3,"Bom mesmo!","Comentário");

insert into fisica(cpf, rg, cod_cliente)
values
("848.494.740-80","42.206.022-7", 1),
("546.617.420-36","49.642.897-4", 2),
("721.928.350-43","33.603.671-1", 3),
("588.952.970-67", "10.631.667-9", 4),
("543.240.420-63","36.517.567-5", 5),
("159.455.740-31","48.172.275-0", 6);

insert into pedidos(cod_pedido, data_pedido, data_entrega, endereco_entrega, cod_cliente)
values
(1, "2022-07-05","2022-08-13","Rua dos Empresarios 90823", 1),
(2, "2022-07-20","2022-08-17","Rua foda123", 2),
(3, "2022-07-13","2022-08-23","Rua dos Bla78364 23", 3),
(4, "2022-06-05","2022-08-05","Rua dos blablabla 89723", 4),
(5, "2022-08-15","2022-09-01","Rua dos Comerciarios 90", 5),
(6, "2022-07-15","2022-08-12","seed: redstone   mundo: Casa automatica", 6);

insert into itens_pedido(cod_produto, cod_pedido, qtd_prod, situacao)
values
(1, 1, 13, 1),
(2, 2, 3, 0),
(3, 3, 5, 1),
(4, 4, 1, 0),
(5, 5, 7, 0),
(6, 6, 12, 1);

insert into juridica(cnpj, razao_social, cod_cliente)
values
("71.787.636/0001-73", "eu quero", 1),
("73.488.267/0001-43", "tenho fome", 2),
("14.465.873/0001-84", "sou lindo", 3),
("75.223.291/0001-86", "namorada", 4),
("07.784.127/0001-98", "nenhuma", 5),
("91.046.287/0001-46", "custo-beneficio", 6);